<div class="body-content" style="margin-top: 99px">
  <?php if (function_exists('yoast_breadcrumb')) {
    yoast_breadcrumb('<p id="breadcrumbs">', '</p>');
  } ?>
  <!-- Nội dung khác của trang hoặc bài đăng -->
</div>